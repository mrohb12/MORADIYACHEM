<?php include('include/config.php'); 

	unset($_SESSION['BLData']);

	?><script>document.location="index.php";</script><?php

?>