<footer class="footer text-right">
	2017 © Sanskartechnolab.                
</footer>